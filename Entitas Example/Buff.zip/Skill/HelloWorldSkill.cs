﻿using CabinIcarus.IcSkillSystem.Runtime.Skills.Components;

namespace Buff.Skill
{
    public class HelloWorldSkill:ISkillDataComponent
    {
        public float NeedMona;
    }
}