﻿using CabinIcarus.IcSkillSystem.Runtime.Buffs.Entitys;

public partial class GameEntity:IEntity
{
}
