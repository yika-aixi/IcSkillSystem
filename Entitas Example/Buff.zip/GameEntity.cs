﻿using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys;

public partial class GameEntity:IEntity
{
}
