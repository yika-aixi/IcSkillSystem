﻿namespace Buff.Components
{
    public enum BuffType
    {
        /// 物理伤害
        AD,
        /// 魔法伤害
        AP,
        ///纯粹伤害 
        Purely
    }
    /// <summary>
    /// buff 类型组件
    /// </summary>
    public interface IBuffTypeComponent
    {
        BuffType Type { get; set; }
    }
}