﻿using System;
using Buff.Skill;
using CabinIcarus.IcSkillSystem.Expansion.Runtime.Buffs.Components;
using CabinIcarus.IcSkillSystem.Expansion.Runtime.Builtin.Buffs;
using CabinIcarus.IcSkillSystem.Expansion.Runtime.Builtin.Buffs.Systems;
using CabinIcarus.IcSkillSystem.Expansion.Runtime.Builtin.Buffs.Unity;
using Entitas;
using Entitas.Unity;
using SkillSystem.SkillSystem.Scripts.Expansion.Runtime.Builtin.Skills.Condition;
using SkillSystem.SkillSystem.Scripts.Expansion.Runtime.Builtin.Skills.Manager;
using UnityEngine;
using Random = UnityEngine.Random;
using IEntity = CabinIcarus.IcSkillSystem.Runtime.Buffs.Entitys.IEntity;
using Object = UnityEngine.Object;

namespace Buff.Components.Test
{
    public class Test : MonoBehaviour
    {
        Entitas.Systems _systems;
        private BuffManager _manager;
        private SkillManager _skillManager;

        public float Min,Max;

        public GameObject Prefab;
        
        void Start()
        {
            var contexts = Contexts.sharedInstance;
        
            _manager = new BuffManager();
            _skillManager = new SkillManager();
            _systems = new Feature("Systems")
                .Add(new InputSystem(_manager,_skillManager, Camera.main, CreateGo, contexts.game));

            //添加buff 系统
            _manager.AddBuffSystem(new DamageReduceFixedSystem(_manager))
                .AddBuffSystem(new DamageReducePercentageSystem(_manager))
                .AddBuffSystem(new ContinuousDamageSystem<DamageBuff>(_manager))
                .AddBuffSystem(new DamageSystem(_manager));
            
            _skillManager.AddSkillSystme(new HelloWorldSkillSystem(_manager));
        }

        private GameObject CreateGo()
        {
            var go = Instantiate(Prefab);
            go.transform.position = new Vector3(Random.Range(Min,Max),0,Random.Range(Min,Max));

            return go;
        }

        void Update()
        {
            _systems.Execute();
            _manager.Update();
        }
    }
    
    public class InputSystem:IExecuteSystem
    {
        private readonly BuffManager _buffManager;
        private readonly SkillManager _skillManager;
        private readonly Camera _camera;
        private readonly Func<GameObject> _createGo;
        private GameContext _gameContext;
        private IEntity _entity;

        public InputSystem(BuffManager buffManager, SkillManager skillManager, Camera camera, Func<GameObject> createGo,
            GameContext gameContext)
        {
            this._buffManager = buffManager;
            this._camera = camera;
            this._createGo = createGo;
            _gameContext = gameContext;
            _skillManager = skillManager;
        }

        public void Execute()
        {
            if (!_camera && _createGo == null)
            {    
                Debug.LogError("没有相机和创建器");
                return;
            }
            
            if (Input.GetMouseButtonDown(1))
            {
                var entity = _gameContext.CreateEntity();

                var go = _createGo();

                var link = go.AddComponent<EntityLink>();
                
                link.Link(entity);

                var entityBuffLink = go.AddComponent<BuffEntityLinkComponent>();
                
                entityBuffLink.Init(_buffManager,entity);
                
                entity.OnDestroyEntity += _ =>
                {
                    link.Unlink();
                    Object.Destroy(go);
                };
                
                _buffManager.AddBuff(entity,new MechanicBuff(MechanicsType.Health)
                {
                    Value = Random.Range(200,1001),
                });
                
                _buffManager.AddBuff(entity,new MechanicBuff(MechanicsType.Mana)
                {
                    Value = Random.Range(200,1001),
                });
            }
            
            if (Input.GetMouseButtonDown(0))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                    if (entityLink)
                    {
                        _entity = (IEntity) entityLink.entity;
                    }
                }
            }

            if (Input.GetKeyDown(KeyCode.A))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                   if (entityLink)
                   {
                       _buffManager.AddBuff((IEntity) entityLink.entity,new DamageBuff()
                       {
                           Maker = _entity,
                           Type = 1,
                           Value = Random.Range(10,20f)
                       });
                   }
                }
            }
            
            if (Input.GetKeyDown(KeyCode.Q))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                    if (entityLink)
                    {
                        _buffManager.AddBuff((IEntity) entityLink.entity,new ContinuousDamageBuff()
                        {
                            Maker = _entity,
                            Type = 2,
                            Value = Random.Range(5,10f),
                            Duration = Random.Range(3,6),
                            TriggerInterval = 1
                        });
                    }
                }
            }
            
            if (Input.GetKeyDown(KeyCode.W))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                    if (entityLink)
                    {
                        _buffManager.AddBuff((IEntity) entityLink.entity,new DamageReduceFixedBuff()
                        {
                            Type = 1,
                            Value = Random.Range(5,10f)
                        });
                    }
                }
            }
            
            if (Input.GetKeyDown(KeyCode.E))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                    if (entityLink)
                    {
                        _buffManager.AddBuff((IEntity) entityLink.entity,new DamageReducePercentageBuff()
                        {
                            Type = 2,
                            Value = Random.Range(10,40)
                        });
                    }
                }
            }
            
            if (Input.GetKeyDown(KeyCode.R))
            {
                var hit = _ray(out var entityLink);
                
                if (hit) 
                {
                    if (entityLink)
                    {
                        _buffManager.AddBuff((IEntity) entityLink.entity,new DamageBuff()
                        {
                            Maker = _entity,
                            Type = 3,
                            Value = Random.Range(30,80)
                        });
                    }
                }
            }
            
            if (Input.GetKeyDown(KeyCode.H))
            {
                var skillDataComponent = new HelloWorldSkill
                {
                    NeedMona = 40
                };
                
                if (new ManaCheck(_buffManager)
                {
                    NeedManaValue = skillDataComponent.NeedMona
                }.Check(_entity))
                {
                    _skillManager.UseSkill(_entity,skillDataComponent);
                }
                else
                {
                    Debug.LogError("没有足够的魔法值!,无法使用技能");
                }
            }
        }

        private bool _ray(out EntityLink link)
        {
            link = null;
            RaycastHit hit;
            Ray ray = _camera.ScreenPointToRay(Input.mousePosition);
            var isHit = Physics.Raycast(ray, out hit);

            if (isHit)
            {
                var go = hit.transform.gameObject;
                link = go.gameObject.GetComponent<EntityLink>();
            }
            
            return isHit;
        }
    }
}