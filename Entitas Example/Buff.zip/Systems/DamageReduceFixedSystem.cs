﻿using System.Collections.Generic;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Systems;
using CabinIcarus.SkillSystem.Runtime.Buffs.Components;
using CabinIcarus.SkillSystem.Scripts.Runtime.Buffs;
using UnityEngine;

namespace Buff.Components.Systems
{
    /// <summary>
    /// 固定减少伤害
    /// </summary>
    public class DamageReduceFixedSystem:ABuffCreateSystem
    {
        private List<DamageReduceFixedBuff> _damageReduceFixedBuffs;
        public DamageReduceFixedSystem(IBuffManager buffManager) : base(buffManager)
        {
            _damageReduceFixedBuffs = new List<DamageReduceFixedBuff>();
        }

        public override bool Filter(IEntity entity, IBuffDataComponent buff)
        {
            return buff is DamageBuff && BuffManager.HasBuff<DamageReduceFixedBuff>(entity) && BuffManager.HasBuff<HPBuff>(entity);
        }

        public override void Create(IEntity entity, IBuffDataComponent buff)
        {
            BuffManager.GetBuffs(entity,_damageReduceFixedBuffs);

            DamageReduceFixedBuff damageReduceFixedBuff = _damageReduceFixedBuffs[0];

            DamageBuff damageBuff = (DamageBuff) buff;
            
            if (damageBuff.Type == damageReduceFixedBuff.Type)
            {
                Debug.LogError($"{damageReduceFixedBuff.Description}");
                damageBuff.Value -= damageReduceFixedBuff.Value;
            }
        }
    }
}