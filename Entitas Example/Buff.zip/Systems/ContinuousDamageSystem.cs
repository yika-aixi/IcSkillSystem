﻿using System.Collections.Generic;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Systems;
using CabinIcarus.SkillSystem.Runtime.Buffs.Components;
using CabinIcarus.SkillSystem.Runtime.Buffs.Systems.Interfaces;
using CabinIcarus.SkillSystem.Scripts.Runtime.Buffs;
using UnityEngine;

namespace Buff.Components.Systems
{
    /// <summary>
    /// 持续伤害
    /// </summary>
    public class ContinuousDamageSystem:ABuffUpdateSystem,IBuffCreateSystem
    {
        private List<ContinuousDamageBuff> _continuousBuffs;
        public ContinuousDamageSystem(IBuffManager buffManager) : base(buffManager)
        {
            _continuousBuffs = new List<ContinuousDamageBuff>();
        }
        public override bool Filter(IEntity entity)
        {
            return BuffManager.HasBuff<HPBuff>(entity);
        }
        public override void Execute(IEntity entity)
        {
            BuffManager.GetBuffs(entity,_continuousBuffs);
            for (var i = 0; i < _continuousBuffs.Count; i++)
            {
                var buff = _continuousBuffs[i];
                buff.Duration -= Time.deltaTime;
                if (buff.Duration > 0)
                {
                    if (buff.LastTriggerTime - buff.Duration >= buff.TriggerInterval)
                    {
                        Debug.LogError($"持续伤害触发,触发间隔{buff.TriggerInterval},持续时间:{buff.Duration}," +
                                       $"剩余时间:{buff.Duration - buff.LastTriggerTime} 每次伤害:{buff.Value} ,伤害类型:{buff.Type}");
                        
                        buff.LastTriggerTime = buff.Duration;
                        
                        BuffManager.AddBuff(entity,new DamageBuff()
                        {
                            Maker = buff.Maker,
                            Type = buff.Type,
                            Value = buff.Value
                        });
                    }
                    else
                    {
                        Debug.LogError($"没到时间,最后触发时间为:{buff.LastTriggerTime},当前时间为:{buff.Duration},触发间隔为:{buff.TriggerInterval}");
                    }
                }
                else
                {
                    BuffManager.RemoveBuff(entity,buff);
                    Debug.LogError("持续时间结束,删除");
                }
            }
        }
        public bool Filter(IEntity entity, IBuffDataComponent buff)
        {
            return BuffManager.HasBuff<HPBuff>(entity) && buff is ContinuousDamageBuff;
        }
        public void Create(IEntity entity, IBuffDataComponent buff)
        {
            ContinuousDamageBuff continuousDamageBuff = (ContinuousDamageBuff) buff;
            continuousDamageBuff.LastTriggerTime = continuousDamageBuff.Duration;
        }
    }
}