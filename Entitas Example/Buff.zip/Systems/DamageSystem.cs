﻿using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Systems;
using CabinIcarus.SkillSystem.Runtime.Buffs.Components;
using CabinIcarus.SkillSystem.Scripts.Runtime.Buffs;
using UnityEngine;

namespace Buff.Components.Systems
{
    public class DamageSystem:ABuffCreateSystem
    {

        public DamageSystem(IBuffManager buffManager) : base(buffManager)
        {
        }

        public override bool Filter(IEntity entity, IBuffDataComponent buff)
        {
            return buff is DamageBuff && BuffManager.HasBuff<HPBuff>(entity); 
        }

        public override void Create(IEntity entity, IBuffDataComponent buff)
        {
            foreach (var hpBuff in BuffManager.GetBuffs<HPBuff>(entity))
            {
                var damageBuff = ((DamageBuff) buff);
                var currentHP = hpBuff.Value;
                hpBuff.Value -= damageBuff.Value;
                
                BuffManager.RemoveBuff(entity,buff);
                
                Debug.LogError($"当前生命:{currentHP},受到伤害:{damageBuff.Value},剩余生命:{hpBuff.Value}");
                
                if (hpBuff.Value <= 0)
                {
                    BuffManager.DestroyEntity(entity);
                    var ent = (Entitas.IEntity) entity;
                    ent.Destroy();
                }
                return;
            }
        }
    }
}