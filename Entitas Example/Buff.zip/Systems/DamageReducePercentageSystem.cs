﻿using System.Collections.Generic;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys;
using Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Systems;
using CabinIcarus.SkillSystem.Runtime.Buffs.Components;
using CabinIcarus.SkillSystem.Scripts.Runtime.Buffs;
using UnityEngine;

namespace Buff.Components.Systems
{
    /// <summary>
    /// 百分比伤害减少
    /// </summary>
    public class DamageReducePercentageSystem:ABuffCreateSystem
    {
        private List<DamageReducePercentageBuff> _damageReducePercentageBuffs;
        public DamageReducePercentageSystem(IBuffManager buffManager) : base(buffManager)
        {
            _damageReducePercentageBuffs = new List<DamageReducePercentageBuff>();
        }

        public override bool Filter(IEntity entity, IBuffDataComponent buff)
        {
            return buff is DamageBuff && BuffManager.HasBuff<DamageReducePercentageBuff>(entity) && BuffManager.HasBuff<HPBuff>(entity);
        }

        public override void Create(IEntity entity, IBuffDataComponent buff)
        {
            BuffManager.GetBuffs(entity,_damageReducePercentageBuffs);

            DamageReducePercentageBuff damageReduceFixedBuff = _damageReducePercentageBuffs[0];

            DamageBuff damageBuff = (DamageBuff) buff;
            
            if (damageBuff.Type == damageReduceFixedBuff.Type)
            {
                Debug.LogError($"{damageReduceFixedBuff.Description},减少:{ damageBuff.Value * damageReduceFixedBuff.Value}点伤害,类型为:{damageBuff.Type}");
                damageBuff.Value -= damageBuff.Value * damageReduceFixedBuff.Value;
            }
        }
    }
}