﻿using CabinIcarus.SkillSystem.Runtime.Buffs.Components;
using Entitas;
using IEntity = Cabin_Icarus.SkillSystem.Scripts.Runtime.Buffs.Entitys.IEntity;

namespace Buff.Components
{
    /// <summary>
    /// 生命值
    /// </summary>
    [Game]
    public class HPBuff:IComponent,IBuffDataComponent,IBuffValueDataComponent
    {
        public float Value { get; set; }
    }

    /// <summary>
    /// 伤害buff
    /// </summary>
    [Game]
    public class DamageBuff:IComponent,IBuffDataComponent,IBuffValueDataComponent,IBuffMakerEntityComponent,IBuffTypeComponent
    {
        /// <summary>
        /// 伤害值
        /// </summary>
        public float Value { get; set; }
        
        /// <summary>
        /// 伤害来源
        /// </summary>
        public IEntity Maker { get; set; }

        /// <summary>
        /// 伤害类型
        /// </summary>
        public BuffType Type { get; set; }
    }

    /// <summary>
    /// 固定伤害减少
    /// </summary>
    [Game]
    public class DamageReduceFixedBuff:IComponent,IBuffDataComponent,IBuffValueDataComponent,IBuffDescriptionComponent,IBuffTypeComponent
    {
        public BuffType Type { get; set; }
        public float Value { get; set; }

        public string Name
        {
            get => $"固定值减少{Type}伤害";
            set{}
        }

        public string Description
        {
            get => $"减少{Type}伤害,{Value}点";
            set{}
        }
    }
    
    /// <summary>
    /// 百分比伤害减少
    /// </summary>
    [Game]
    public class DamageReducePercentageBuff:IComponent,IBuffDataComponent,IBuffValueDataComponent,IBuffDescriptionComponent,IBuffTypeComponent
    {
        public BuffType Type { get; set; }
        private float _value;

        public float Value
        {
            get { return _value; }
            set { _value = value / 100; }
        }

        public string Name
        {
            get =>$"百分比减少{Type}伤害";
            
            set{}
        }

        public string Description
        {
            get => $"减少{Type}伤害,{Value * 100}%";
            set{}
        }
    }

    /// <summary>
    /// 持续伤害
    /// </summary>
    [Game]
    public class ContinuousDamageBuff:IComponent,IBuffDataComponent,IBuffValueDataComponent,IBuffDescriptionComponent,IBuffTypeComponent,IBuffTriggerTime,IBuffTimeDataComponent,IBuffMakerEntityComponent
    {
        public BuffType Type { get; set; }

        private float _value;

        public float Value
        {
            get { return _value; }
            set { _value = value / 100; }
        }

        public string Name { get; set; } = "百分比伤害减少";

        public string Description
        {
            get => $"减少{Value * 100}%伤害";
            set {}
        }

        public float LastTriggerTime { get; set; }
        public float TriggerInterval { get; set; }
        public float Duration { get; set; }
        public IEntity Maker { get; set; }
    }
}